
###############################
### Demon - USB Backup Tool ###
## By Felix - DemonTechStuff ##
###############################

###########################################################################################################################
1.| 	Click on the file extensions you want to save. The chosen files will be saved to your stick.
_/	(a click on the headline chooses every file extension of this category, another click inverts your choices)

	Klicke die gewünschten Dateitypen an, die du auf deinen Stick kopieren willst.
	(Ein Klick auf die Überschriften wählt alle Dateitypen der Kategorie aus, ein weiterer Klick macht dies rückgängig)
___________________________________________________________________________________________________________________________
2.|	Click on the big "Sicherung Starten"-Button to start saving, the progress will be shown in a new window.
_/
	Klicke auf den großen "Sicherung Starten" Knopf um mit der Sicherung zu beginnen, 
	dein Fortschritt wird in einem neuen Fenster angezeigt.
	
	Um das Kopieren abzubrechen klicke auf "Sicherung Abbrechen". Das Fenster zu schließen bricht nicht die Sicherung ab!
___________________________________________________________________________________________________________________________
3.|	Ein neues Backup wird die aktuelle Sicherung überschreiben, 
_/	du kannst die aktuelle Version abspeichern (versionieren) indem du auf "Archiviere Backup" klickst.

	Das Backup Tool unterstützt 7-Zip welcher eine bessere und schnelle Archivierung als Windows bietet.
	7-Zip ist eine großartige Alternative zu "WinRar" oder "WinZip"
	Die Installationsdatei für 7-Zip befindet sich in der "Toolbox" auf dem Stick.
	7-Zip verwendet "*.7z", Windows verwendet das bekannte "*.zip" welches auch von 7-Zip verwendet wird
	weiteres unter https://7-zip.de/
############################################################################################################################
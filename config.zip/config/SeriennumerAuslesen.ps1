﻿$FSO = New-Object -com  Scripting.FileSystemObject
$FSO.Drives | foreach {
    $Drive = $_
write-host $drive.path
write-host $FSO.GetDrive($Drive.path).SerialNumber
}
start-sleep 30